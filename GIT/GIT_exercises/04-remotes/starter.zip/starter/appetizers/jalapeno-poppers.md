# Jalapeno Poppers

## Ingredients

- 1 (4 ounce) package cream cheese, softened
- 4 ounces shredded Cheddar cheese
- 6 ounces fresh corn kernals
- salt and ground black pepper to taste
- 8 fresh jalapeno peppers, halved lengthwise and seeded
- 8 slices bacon, cut in half
- 16 toothpicks

## Preparation

Preheat an outdoor grill for medium-high heat, and lightly oil the grate.

Mix together the cream cheese, Cheddar cheese, corn, salt, and black pepper in a bowl.

Fill the jalapeno halves with the cream cheese mixture.

Wrap each stuffed pepper with bacon, securing it with a toothpick. Be sure the toothpick pokes through the bacon as well as the pepper.

Place the poppers face down on the grill over direct heat. Grill until bacon is crispy and brown, about 5 minutes; turn the poppers over and grill until bacon is crisp on other side, 5 more minutes.
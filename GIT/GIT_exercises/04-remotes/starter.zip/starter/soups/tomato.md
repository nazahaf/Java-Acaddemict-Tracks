# Tomato Soup

## Ingredients

- 2 pounds Roma (plum) tomatoes, quartered
- 3 tablespoons olive oil
- 4 cloves garlic
- 1 quart chicken stock
- 1/4 cup chopped fresh basil
- 1/2 tablespoon balsamic vinegar
- salt to taste
- ground black pepper to taste 

## Preparation


- Place the tomato halves, cut side up, on a baking tray with the garlic cloves. Drizzle with the oil, and sprinkle with salt and pepper. Roast at 375 degrees F (195 degrees C) for 1 hour.
- Snip the ends off the garlic cloves, and squeeze the insides into the bowl of a food processor along with the entire contents of the baking tray. Add stock, basil, and vinegar; blend until smooth. Season to taste. Serve either hot or cold.
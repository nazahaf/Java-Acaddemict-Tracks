# git-course-recipes
Repository used for exercises in Realdolmen Education's Git training. See https://education.realdolmen.com/en/Course/GIT010

# Hamburger

## Ingredients

- 2 pounds ground beef
- 1 egg, beaten
- 3/4 cup dry bread crumbs
- 3 tablespoons evaporated milk
- 2 tablespoons Worcestershire sauce
- 1/8 teaspoon cayenne pepper
- 2 cloves garlic, minced 
- 2 slices of cheeze
- 1 tomato
- salad

## Preparation

Preheat grill for high heat.

In a large bowl, mix the ground beef, egg, bread crumbs, evaporated milk, Worcestershire sauce, cayenne pepper, and garlic using your hands. Form the mixture into 8 hamburger patties.

Lightly oil the grill grate. Grill patties 5 minutes per side, or until well done.

Add tomato and salad to your tasting in layers. Add the Layer slices of cheese on top of hamburger on a sandwich.

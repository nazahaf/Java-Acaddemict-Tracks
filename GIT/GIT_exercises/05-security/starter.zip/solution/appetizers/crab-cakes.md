# Crab Cakes

## Ingredients

- 1 egg
- 3 tablespoons mayonnaise
- 4 teaspoons lemon juice
- 1/8 teaspoon red pepper flakes
- 1 teaspoon dried tarragon
- 1 tablespoon minced green onions
- 8 ounces crabmeat
- 1/2 cup crushed buttery round crackers
- 1 tablespoon butter 

## Preparation

In a medium bowl, whisk together egg, mayonnaise, lemon juice, red pepper flakes, tarragon, and scallions. Gently stir in crabmeat, being careful not to break up meat. Gradually mix in cracker crumbs, adding until desired consistency is achieved.

Heat butter in a skillet over medium heat. Form crab mixture into 4 patties. Place patties in skillet, and cook until golden brown, about 5 to 6 minutes on each side.

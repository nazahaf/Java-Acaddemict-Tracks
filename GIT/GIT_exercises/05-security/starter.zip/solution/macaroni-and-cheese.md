# Macaroni and Cheese

## Ingredients

- 2 slices bacon
- 8 ounces penne pasta
- 1 onion, chopped
- 1 clove garlic, minced
- 3 cups shredded Cheddar cheese
- 2 tablespoons butter
- 3 tablespoons all-purpose flour
- 2 cups milk 

## Preparation

Preheat oven to 350 degrees F (175 degrees C).

Place bacon in a large, deep skillet. Cook over medium high heat until evenly brown. Drain, crumble and set aside.

In a large pot with boiling salted water cook pasta until al dente. Drain.

In a medium skillet saute the chopped onion, and minced garlic. Take off heat and add chopped cooked bacon and set aside.

To make the sauce, in a medium saucepan melt the butter or margarine over low heat. Once melted, add the flour and stir constantly for 2 minutes. Gradually add milk and continue stirring until thickened. Stir in 2 cups of the grated Cheddar cheese and stir until melted.

Combine cooked pasta, sauteed vegetables and sauce. Pour into a 2 quart casserole dish. Add the last cup of grated Cheddar cheese to top of mixture.

Bake uncovered in preheated oven until cheese on top is melted and brown, 15 to 20 minutes. Serve warm.
